var AssetLoader = (function () {
    function AssetLoader() { }
    return AssetLoader;
})();
