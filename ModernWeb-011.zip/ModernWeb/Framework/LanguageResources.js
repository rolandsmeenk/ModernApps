var LanguageResources = (function () {
    function LanguageResources() { }
    return LanguageResources;
})();
