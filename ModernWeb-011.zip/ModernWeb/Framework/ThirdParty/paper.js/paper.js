// Paper.js loader for development, as produced by the build/load.sh script
document.write('<script type="text/javascript" src="../../lib/prepro.js"></script>');
document.write('<script type="text/javascript" src="../../src/load.js"></script>');

// For more information on building the library please refer to the
// 'Building the Library' section of README.md:
// https://github.com/paperjs/paper.js#building-the-library
