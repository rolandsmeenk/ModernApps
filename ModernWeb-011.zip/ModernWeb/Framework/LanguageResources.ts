﻿class LanguageResources {



}

